# PROMPTS.md - Antigravity prompt log (ENG-139055)

Log each prompt exactly as sent, plus the outcome.

## Prompt 1 - Context and constraints
**Prompt:** (paste the Acceptance Criteria and NFRs from the TRD; say: planning phase only, no feature code)
**Outcome:** _fill in_

## Prompt 2 - ERD
**Prompt:** _fill in_
**Outcome:** _fill in_

## Prompt 3 - API contracts
**Prompt:** _fill in_
**Outcome:** _fill in_

## Prompt 4 - Test suite first (next phase)
**Prompt:** _fill in_
**Outcome:** _fill in_

## Iterations / reverts
- _"That approach caused an error. Let's revert and try a different method."_ - note what broke and what fixed it.
