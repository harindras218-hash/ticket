const mongoose = require('mongoose');

const QrCodeSchema = new mongoose.Schema({
  ticketId: { type: mongoose.Schema.Types.ObjectId, ref: 'Ticket', required: true, unique: true },
  payload: { type: String, required: true }, // signed token, contains no PII
  imageDataUrl: { type: String },
  generatedAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('QrCode', QrCodeSchema);
