const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 80 },
    email: { type: String, required: true, unique: true, lowercase: true, match: /^\S+@\S+\.\S+$/ },
    passwordHash: { type: String, required: true },
    role: { type: String, enum: ['manager', 'staff'], default: 'staff' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('User', UserSchema);
