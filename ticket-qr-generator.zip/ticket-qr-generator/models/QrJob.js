const mongoose = require('mongoose');

const QrJobSchema = new mongoose.Schema(
  {
    qrCodeId: { type: mongoose.Schema.Types.ObjectId, ref: 'QrCode' },
    ticketId: { type: mongoose.Schema.Types.ObjectId, ref: 'Ticket', required: true },
    status: { type: String, enum: ['queued', 'processing', 'done', 'failed'], default: 'queued' },
    attempts: { type: Number, default: 0, min: 0 },
    lastError: { type: String },
  },
  { timestamps: true }
);

module.exports = mongoose.model('QrJob', QrJobSchema);
