const mongoose = require('mongoose');

const EventSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 120 },
    venue: { type: String, required: true, trim: true, maxlength: 120 },
    startsAt: { type: Date, required: true },
    capacity: { type: Number, required: true, min: 1 },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Event', EventSchema);
