const mongoose = require('mongoose');

const ScanLogSchema = new mongoose.Schema({
  ticketId: { type: mongoose.Schema.Types.ObjectId, ref: 'Ticket', required: true },
  scannedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  result: { type: String, enum: ['valid', 'duplicate', 'invalid', 'cancelled'], required: true },
  scannedAt: { type: Date, default: Date.now },
});

ScanLogSchema.index({ ticketId: 1, scannedAt: -1 });

module.exports = mongoose.model('ScanLog', ScanLogSchema);
