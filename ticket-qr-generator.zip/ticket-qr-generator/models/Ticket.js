const mongoose = require('mongoose');

// Strip angle brackets so stored text cannot carry HTML/script (XSS hardening at the data layer).
const clean = (v) => (typeof v === 'string' ? v.replace(/[<>]/g, '').trim() : v);

const TicketSchema = new mongoose.Schema(
  {
    eventId: { type: mongoose.Schema.Types.ObjectId, ref: 'Event', required: true, index: true },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    holderName: { type: String, required: true, maxlength: 80, set: clean },
    holderEmail: { type: String, required: true, lowercase: true, match: /^\S+@\S+\.\S+$/ },
    ticketNumber: { type: String, required: true, unique: true },
    status: { type: String, enum: ['active', 'used', 'cancelled'], default: 'active' },
  },
  { timestamps: true }
);

TicketSchema.index({ eventId: 1, status: 1 });

module.exports = mongoose.model('Ticket', TicketSchema);
