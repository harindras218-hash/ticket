module.exports = {
  User: require('./User'),
  Event: require('./Event'),
  Ticket: require('./Ticket'),
  QrCode: require('./QrCode'),
  QrJob: require('./QrJob'),
  ScanLog: require('./ScanLog'),
};
