# API Contracts

Response envelope for every endpoint:

```json
{ "success": true, "data": {}, "error": null }
{ "success": false, "data": null, "error": { "code": "VALIDATION_ERROR", "message": "Invalid input", "fields": ["holderEmail"] } }
```

All routes except `POST /api/auth/login` need `Authorization: Bearer <token>`.

| Method | Endpoint | Purpose | Success | Errors |
|---|---|---|---|---|
| POST | /api/auth/login | Log in | 200 token | 401 |
| GET | /api/tickets?eventId=&status=&q=&page= | List or search tickets | 200 (empty array shows "No data found") | 401 |
| POST | /api/tickets | Create ticket and enqueue QR job | 202 `{ ticket, jobId }` | 400 with `fields`, 401 |
| GET | /api/tickets/:id | Ticket detail with QR | 200 | 404 |
| PATCH | /api/tickets/:id | Update or cancel ticket | 200 | 400, 404 |
| GET | /api/jobs/:jobId | Poll QR generation status | 200 `{ status }` | 404 |
| POST | /api/tickets/:id/qr/retry | Retry a failed QR job | 202 | 404, 409 |
| POST | /api/scan | Validate a scanned payload | 200 `{ result }` | 400, 404 |
| GET | /api/events | List events | 200 | 401 |
| POST | /api/events | Create event (manager only) | 201 | 400, 403 |

## Sample: POST /api/tickets

Request
```json
{ "eventId": "66f0c0ffee0000000000abcd", "holderName": "Ravi Kumar", "holderEmail": "ravi@example.com" }
```
Response 202
```json
{ "success": true, "data": { "ticket": { "ticketNumber": "T-0001", "status": "active" }, "jobId": "66f0c0ffee0000000000dcba" }, "error": null }
```

## Rules
- Server validates and returns 400 with a `fields` array so the UI can highlight those inputs in red.
- Text inputs are sanitized (HTML characters stripped) before storing.
- Client shows a loading indicator while polling `/api/jobs/:jobId`.
