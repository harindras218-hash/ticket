# Ticket QR Code Generator Worker (ENG-139055)

**Phase:** Database Schema - ERD and API contracts. No feature code yet.

## Problem
Client staff track tickets on paper and Excel, causing data loss and slowdowns. This project plans a digital Ticket QR Code Generator Worker that floor staff can use, including on slow connections.

## Tech stack
Node.js, MongoDB (Mongoose), REST API. Testing with Jest/Vitest in the next phase.

## Contents
- `docs/ERD.md` - entity relationship diagram (Mermaid)
- `docs/API-CONTRACTS.md` - endpoints, envelope, samples
- `models/` - Mongoose schema definitions (architecture only)
- `PROMPTS.md` - prompt traceability log

## Run in VS Code
1. Open this folder: File > Open Folder.
2. Open a terminal (Ctrl+`) and run:
   ```
   npm install
   npm run check
   ```
   `npm run check` validates the schemas offline (no database needed).
3. Open `docs/ERD.md` and press Ctrl+Shift+V to see the diagram.

## Unhappy-path design
- Empty state: list endpoints return `[]`; UI shows "No data found".
- Slow network: QR generation is an async `QrJob`; UI polls status with a loader.
- Invalid input: 400 with `fields` array; UI highlights those fields in red.
- XSS: text sanitized before storing.
