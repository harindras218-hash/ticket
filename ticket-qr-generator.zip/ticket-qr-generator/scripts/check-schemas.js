// Offline schema sanity check - no database needed.
const mongoose = require('mongoose');
const { User, Event, Ticket, QrCode, QrJob, ScanLog } = require('../models');

const id = () => new mongoose.Types.ObjectId();
let failed = 0;

function expect(label, doc, shouldBeValid) {
  const err = doc.validateSync();
  const ok = shouldBeValid ? !err : !!err;
  if (!ok) failed++;
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}`);
}

expect('User valid', new User({ name: 'Asha', email: 'asha@example.com', passwordHash: 'x' }), true);
expect('User bad email rejected', new User({ name: 'Asha', email: 'nope', passwordHash: 'x' }), false);
expect('Event valid', new Event({ name: 'Concert', venue: 'Hall A', startsAt: new Date(), capacity: 100 }), true);
expect('Event capacity 0 rejected', new Event({ name: 'Concert', venue: 'Hall A', startsAt: new Date(), capacity: 0 }), false);

const good = { eventId: id(), createdBy: id(), holderName: 'Ravi', holderEmail: 'ravi@example.com', ticketNumber: 'T-0001' };
expect('Ticket valid', new Ticket(good), true);
expect('Ticket missing name rejected', new Ticket({ ...good, holderName: undefined }), false);
expect('Ticket bad status rejected', new Ticket({ ...good, status: 'lost' }), false);

const xss = new Ticket({ ...good, holderName: '<script>alert(1)</script>Ravi' });
const safe = !/[<>]/.test(xss.holderName);
if (!safe) failed++;
console.log(`${safe ? 'PASS' : 'FAIL'}  XSS characters stripped from holderName -> "${xss.holderName}"`);

expect('QrCode valid', new QrCode({ ticketId: id(), payload: 'signed.token' }), true);
expect('QrJob valid', new QrJob({ ticketId: id() }), true);
expect('ScanLog valid', new ScanLog({ ticketId: id(), scannedBy: id(), result: 'valid' }), true);

console.log(failed ? `\n${failed} check(s) failed` : '\nAll schema checks passed');
process.exit(failed ? 1 : 0);
